Information , about movement of ghosts:

1 - always chases pacman with breath 
first search(BFS) algorithm

2 - 50% chases pacman with BFS and 
other 50% random movement (there is 
also restrictions with their help, 
when ghost entered tunnel, he have 
to exit and after this to change his 
direction, because he will cycle if 
there are no restrictions)

3 - with BFS goes from one corner to 
other

4 - random movement

When you take power dot : three ghosts 
will go back to the starting point and
the fourth ghost will try to go to starting 
point, but 50% of his movement is random 
and can't come back so fast like others. 
This movement I named drunken movement.

Pacman will be immortal for 10 seconds 
and in this time you can eat ghost. They 
will go to their starting point.